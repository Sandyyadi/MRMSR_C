from entropy_estimators import *


def mrmsr(X, y, **kwargs):
    """
    This function implements the basic scoring criteria for linear combination of shannon information term.
    The scoring criteria is calculated based on the formula j_mrmsr=I(f,y)/H(y)-beta*sum_j(1-(I(fj, y, f)+I(f, y, fj))/2*H(y))=I(f;y)-beta*sum_j(I(fj;f))+gamma*sum(I(fj;f|y))

    Input
    -----
    X: {numpy array}, shape (n_samples, n_features)
        input data, guaranteed to be a discrete data matrix
    y: {numpy array}, shape (n_samples,)
        input class labels
    kwargs: {dictionary}
        Parameters for different feature selection algorithms.
        beta: {float}
            beta is the parameter in j_mrmsr=I(f,y)/H(y)-beta*sum_j(1-(I(fj, y, f)+I(f, y, fj))/2*H(y)), which is (1/(k-1)).
        gamma: {float}
            gamma is the parameter in j_mrmsr=I(f;y)-beta*sum(I(fj;f))+gamma*sum(I(fj;f|y))
        function_name: {string}
            name of the feature selection function
        n_selected_features: {int}
            number of features to select

    Output
    ------
    F: {numpy array}, shape: (n_features,)
        index of selected features, F[0] is the most important feature
    J_MRMSR: {numpy array}, shape: (n_features,)
        corresponding objective function value of selected features
    MIfy: {numpy array}, shape: (n_features,)
        corresponding mutual information between selected features and response
    """

    n_samples, n_features = X.shape
    # index of selected features, initialized to be empty
    F = []
    # Objective function value for selected features
    J_MRMSR = []
    # Mutual information between feature and response
    MIfy = []
    # indicate whether the user specifies the number of features
    is_n_selected_features_specified = False
    if 'n_selected_features' in kwargs.keys():
        n_selected_features = kwargs['n_selected_features']
        is_n_selected_features_specified = True

    # select the feature whose j_mrmsr is the largest
    # t1 stores I(f;y) for each feature f
    t1 = np.zeros(n_features)
    # t2 stores 1-(I(fj, y, f)+I(f, y, fj))/2*H(y) for each feature f
    t2 = np.zeros(n_features)
    # t3 stores sum_j(I(fj;f|y)) for each feature f
    #t3 = np.zeros(n_features)
    for i in range(n_features):
        f = X[:, i]
        t1[i] = midd(f, y)/entropyd(y)

    # make sure that j_mrmsr is positive at the very beginning
    j_mrmsr = 1

    while True:
        if len(F) == 0:
            # select the feature whose mutual information is the largest
            idx = np.argmax(t1)
            F.append(idx)
            J_MRMSR.append(t1[idx])
            MIfy.append(t1[idx])
            f_select = X[:, idx]

        if is_n_selected_features_specified:
            if len(F) == n_selected_features:
                break
        else:
            if j_mrmsr < 0:
                break

        # we assign an extreme small value to j_mrmsr to ensure it is smaller than all possible values of j_mrmsr
        j_mrmsr = -1E30

        for i in range(n_features):
            if i not in F:
                f = X[:, i]
                t2[i] += 1-(cmidd(f_select, y, f)+cmidd(f, y, f_select))/(2*entropyd(y))
                #t3[i] += (cmidd(f_select, y, f)+cmidd(f, y, f_select))/2*entropyd(y)
                # calculate j_mrmsr for feature i (not in F)
                t = t1[i] - (1.0 / len(F))*t2[i]
                # record the largest j_mrmsr and the corresponding feature index
                if t > j_mrmsr:
                    j_mrmsr = t
                    idx = i
        F.append(idx)
        J_MRMSR.append(j_mrmsr)
        MIfy.append(t1[idx])
        f_select = X[:, idx]

    return np.array(F), np.array(J_MRMSR), np.array(MIfy)





